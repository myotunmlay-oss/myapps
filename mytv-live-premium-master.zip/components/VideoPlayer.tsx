import React, { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { AdBanner } from '../types';

interface VideoPlayerProps {
  options: any;
  currentUrl: string;
  matchInfo?: {
    home: string;
    away: string;
    score?: string;
  };
  onFailure?: (url: string) => void;
  logoText?: string;
  logoUrl?: string;
  logoSize?: number;
  logoPosition?: 'left' | 'right';
  logoOffsetX?: number;
  logoOffsetY?: number;
  showBrandingLogo?: boolean;
  themeClasses: { errorOverlayBg: string };
  viewerCount?: number;
  ads?: AdBanner[];
  adsWidth?: number;
  adsBottom?: number;
}

const VideoPlayer: React.FC<VideoPlayerProps> = ({ 
  options, 
  currentUrl, 
  matchInfo,
  onFailure, 
  logoText = "MYTV LIVE", 
  logoUrl,
  logoSize = 14, 
  logoPosition = 'right', 
  logoOffsetX = 5,
  logoOffsetY = 5,
  showBrandingLogo = true, 
  themeClasses,
  viewerCount = 0,
  ads = [],
  adsWidth = 50,
  adsBottom = 2
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const playerRef = useRef<any>(null);
  const [playerEl, setPlayerEl] = useState<HTMLElement | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isLoadingLong, setIsLoadingLong] = useState(false);
  const [lastTap, setLastTap] = useState(0);
  const loadingTimeoutRef = useRef<number | null>(null);
  const [isBuffering, setIsBuffering] = useState(false);
  
  const [currentAdIndex, setCurrentAdIndex] = useState(0);

  useEffect(() => {
    if (ads && ads.length > 1) {
      const interval = setInterval(() => {
        setCurrentAdIndex((prev) => (prev + 1) % ads.length);
      }, 7000);
      return () => clearInterval(interval);
    }
  }, [ads]);

  const initPlayer = () => {
    const videojs = (window as any).videojs;
    if (!videojs || !videoRef.current || !currentUrl) {
      if (!currentUrl) setError('ဗီဒီယို URL ရှာမတွေ့ပါ။');
      return;
    }

    if (playerRef.current) {
      try {
        playerRef.current.dispose();
      } catch (e) {
        console.warn("Cleanup error avoided:", e);
      }
      playerRef.current = null;
      setPlayerEl(null);
    }

    setError(null);
    setIsLoadingLong(false);
    setIsBuffering(false);
    
    if (loadingTimeoutRef.current) clearTimeout(loadingTimeoutRef.current);
    loadingTimeoutRef.current = window.setTimeout(() => setIsLoadingLong(true), 12000); 

    const playerOptions = {
      ...options,
      autoplay: true,
      muted: false, 
      controls: true,
      responsive: true,
      fill: true,
      fluid: true,
      preload: 'auto',
      liveui: true,
      playbackRates: [1],
      html5: {
        vhs: { 
          overrideNative: !videojs.browser.IS_SAFARI,
          enableLowInitialPlaylist: true,
          fastQualityChange: false,
          smoothQualityChange: false,
          bandwidth: 8388608,
          goalBufferLength: 45,
          bufferLowWatermark: 5
        },
      },
      controlBar: {
        children: [
          'playToggle',
          'volumePanel',
          'currentTimeDisplay',
          'progressControl',
          'liveDisplay',
          'remainingTimeDisplay',
          'fullscreenToggle',
        ],
      },
    };

    try {
      const player = playerRef.current = videojs(videoRef.current, playerOptions);
      setPlayerEl(player.el());

      player.ready(() => {
        player.muted(false);
        player.volume(1.0);
        
        if (currentUrl) {
          player.src({
            src: currentUrl,
            type: 'application/x-mpegURL'
          });
          
          const playPromise = player.play();
          if (playPromise !== undefined) {
            playPromise.then(() => {
              player.muted(false);
              player.volume(1.0);
            }).catch(() => {
              player.muted(true);
              player.play().then(() => {
                player.muted(false);
                player.volume(1.0);
              });
            });
          }
        }
      });

      player.on('playing', () => {
        setIsBuffering(false);
        setIsLoadingLong(false);
        player.muted(false);
        player.volume(1.0);
        if (loadingTimeoutRef.current) clearTimeout(loadingTimeoutRef.current);
      });

      player.on('waiting', () => setIsBuffering(true));

      player.on('error', () => {
        if (loadingTimeoutRef.current) clearTimeout(loadingTimeoutRef.current);
        setError(`ဗီဒီယို လိုင်းချက်ဆက်မှု အဆင်မပြေပါ။`);
        if (onFailure) onFailure(currentUrl);
      });

    } catch (e) {
      setError("ဗီဒီယို စနစ်တွင် အမှားတစ်ခု ဖြစ်ပေါ်နေပါသည်။");
    }
  };

  useEffect(() => {
    if (currentUrl) initPlayer();
    return () => {
      if (loadingTimeoutRef.current) clearTimeout(loadingTimeoutRef.current);
      if (playerRef.current) {
        try { playerRef.current.dispose(); } catch (e) {}
      }
    };
  }, [currentUrl]);

  const handleDoubleTap = (e: React.MouseEvent | React.TouchEvent) => {
    const now = Date.now();
    if (now - lastTap < 300) {
      const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
      const x = 'clientX' in e ? e.clientX : (e as any).touches[0].clientX;
      const relativeX = x - rect.left;
      if (playerRef.current) {
        const curr = playerRef.current.currentTime();
        if (relativeX < rect.width / 2) playerRef.current.currentTime(Math.max(0, curr - 10));
        else playerRef.current.currentTime(curr + 10);
      }
    }
    setLastTap(now);
  };

  const logoStyle: React.CSSProperties = {
    top: `${logoOffsetY}%`,
    [logoPosition === 'left' ? 'left' : 'right']: `${logoOffsetX}%`,
    position: 'absolute',
    zIndex: 100,
    pointerEvents: 'none',
    userSelect: 'none',
    opacity: 0.9,
  };

  // We use CSS clamp() to make the logo size responsive relative to the viewport.
  // clamp(MIN, VAL, MAX)
  // MIN: prevent it from being too tiny on mobile.
  // MAX: prevent it from being huge on desktop.
  // VAL: relative scale using vw (viewport width).
  const responsiveFontSize = `clamp(8px, calc(1vw + ${logoSize}px), 80px)`;
  const responsiveImageWidth = `clamp(30px, calc(5vw + ${logoSize * 3}px), 400px)`;

  const LogoOverlay = (
    <div style={logoStyle}>
      {logoUrl ? (
        <img 
          src={logoUrl} 
          style={{ width: responsiveImageWidth, height: 'auto', display: 'block' }} 
          alt="Logo" 
        />
      ) : (
        <div 
          className="bg-black/40 backdrop-blur-md px-[1em] py-[0.5em] rounded-[0.8rem] border border-white/10 shadow-2xl"
          style={{ fontSize: responsiveFontSize }}
        >
           <span className="font-black italic tracking-tighter uppercase text-white">
             <span className="text-[#00ff88]">{logoText.split(' ')[0]}</span> {logoText.split(' ').slice(1).join(' ')}
           </span>
        </div>
      )}
    </div>
  );

  const ViewersOverlay = (
    <div className="absolute top-[5%] left-[5%] z-[110] pointer-events-none">
      <div className="bg-black/60 backdrop-blur-md px-3 py-1.5 rounded-full border border-white/10 flex items-center gap-2">
        <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse"></span>
        <span className="text-[10px] font-black text-white">{viewerCount.toLocaleString()} LIVE</span>
      </div>
    </div>
  );

  const AdsOverlay = ads && ads.length > 0 && (
    <div 
      className="absolute left-1/2 -translate-x-1/2 z-[105] animate-in slide-in-from-bottom-2 duration-500 transition-all pointer-events-none bg-transparent"
      style={{ 
        bottom: `${adsBottom}%`, 
        width: `${adsWidth}%`,
        maxWidth: '100%'
      }}
    >
      <div className="relative pointer-events-auto flex justify-center items-end bg-transparent">
        {ads.map((ad, idx) => (
          <a 
            key={idx}
            href={ad.link || '#'} 
            target="_blank" 
            rel="noopener noreferrer"
            className={`transition-opacity duration-1000 block w-full bg-transparent ${idx === currentAdIndex ? 'opacity-100' : 'absolute inset-0 opacity-0 pointer-events-none'}`}
          >
            <img 
              src={ad.image} 
              className="w-full h-auto object-contain block mx-auto bg-transparent border-none shadow-none" 
              alt={`Ad ${idx}`} 
            />
          </a>
        ))}
      </div>
    </div>
  );

  return (
    <div className="w-full h-full bg-black flex items-center justify-center relative overflow-hidden group" onClick={handleDoubleTap}>
      {playerEl && createPortal(ViewersOverlay, playerEl)}
      {playerEl && showBrandingLogo && createPortal(LogoOverlay, playerEl)}
      {playerEl && !error && !isBuffering && createPortal(AdsOverlay, playerEl)}

      {(isLoadingLong || isBuffering) && !error && (
        <div className="absolute inset-0 z-[65] bg-black/80 flex flex-col items-center justify-center text-center p-6 backdrop-blur-sm">
           <div className="w-14 h-14 border-4 border-[#00ff88]/10 border-t-[#00ff88] rounded-full animate-spin mb-4"></div>
           <p className="text-[#00ff88] text-[10px] font-black uppercase tracking-[0.3em] animate-pulse">{isBuffering ? 'Buffering...' : 'Loading Smooth Stream...'}</p>
        </div>
      )}

      {error && (
        <div className={`absolute inset-0 z-[70] ${themeClasses.errorOverlayBg} flex flex-col items-center justify-center p-10 text-center backdrop-blur-md`}>
          <div className="w-16 h-16 bg-red-500/10 rounded-3xl flex items-center justify-center mb-6 border border-red-500/20 text-3xl">📡</div>
          <p className="text-white text-[14px] font-black mb-2 uppercase tracking-tight">{error}</p>
          <p className="text-gray-400 text-[11px] font-bold mb-6 max-w-[240px] leading-relaxed uppercase">ကျေးဇူးပြု၍ အခြားဆာဗာ (Channel) ကို ပြောင်းလဲပေးပါ။</p>
          <div className="py-3 px-8 border border-[#00ff88]/30 rounded-2xl bg-[#00ff88]/5">
             <span className="text-[#00ff88] text-[10px] font-black uppercase tracking-widest">ဆာဗာပြောင်းပါ</span>
          </div>
        </div>
      )}
      
      <div data-vjs-player className="w-full h-full">
        <video 
          ref={videoRef} 
          className="video-js vjs-big-play-centered vjs-fill vjs-theme-exo" 
          playsInline
          crossOrigin="anonymous"
        />
      </div>
    </div>
  );
};

export default VideoPlayer;