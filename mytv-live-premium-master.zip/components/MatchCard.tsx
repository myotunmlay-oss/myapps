
import React from 'react';
import { Match } from '../types';

interface MatchCardProps {
  match: Match;
  index: number;
  onPlay: (match: Match) => void;
  isActive?: boolean;
  themeClasses: { 
    matchCardBg: string; 
    matchCardHoverBg: string; 
    matchCardTeamLogoGradFrom: string; 
    matchCardTeamLogoGradTo: string; 
    innerBg: string;
  };
}

const MatchCard: React.FC<MatchCardProps> = ({ match, index, onPlay, isActive, themeClasses }) => {
  if (!match || !match.servers || !Array.isArray(match.servers)) return null;

  const filteredServers = match.servers.filter(s => s && s.url);
  
  if (filteredServers.length === 0) return null;

  const matchStart = (Number(match.match_time) || 0) * 1000;
  const now = Date.now();
  const matchEnd = matchStart + (150 * 60 * 1000); 
  const isLive = now >= matchStart && now < matchEnd;

  const formatDateTime = (timestamp: any) => {
    const ts = Number(timestamp);
    if (isNaN(ts)) return "LIVE";
    const date = new Date(ts * 1000);
    const dateStr = date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short' });
    const timeStr = date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
    return `${dateStr} • ${timeStr}`;
  };

  const getScore = (val: any) => {
    if (val === undefined || val === null || val === "") return 0;
    return val;
  };

  return (
    <div 
      onClick={() => onPlay(match)}
      className={`relative border border-white/5 rounded-xl p-3 sm:p-4 transition-all cursor-pointer bg-white/5 hover:bg-white/10 ${
        isActive ? 'border-[#ffaa00] bg-[#ffaa00]/5 ring-1 ring-[#ffaa00]/20' : ''
      } group select-none`}
    >
      {/* League Header */}
      <div className="flex justify-between items-start mb-3">
        <div className="flex items-center gap-1.5 min-w-0 flex-1">
          {isLive && <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse shrink-0"></span>}
          <span className={`text-[7px] sm:text-[9px] font-black uppercase tracking-widest truncate ${isLive ? 'text-red-500' : 'text-gray-500'}`}>
            {match.league_name || 'LIVE MATCH'}
          </span>
        </div>
        <div className={`px-2 py-0.5 rounded-sm text-[7px] sm:text-[8px] font-black uppercase tracking-tighter ${isActive ? 'bg-[#ffaa00] text-black' : (isLive ? 'bg-red-500 text-white' : 'bg-white/5 text-gray-400')}`}>
          {isActive ? 'WATCHING' : (isLive ? 'LIVE' : 'VIEW')}
        </div>
      </div>

      {/* Teams Row */}
      <div className="flex items-center justify-between gap-2 sm:gap-3">
        <div className="flex flex-col items-center flex-1 min-w-0">
          <div className="w-8 h-8 sm:w-10 sm:h-10 flex items-center justify-center p-1 bg-white/5 rounded-lg mb-2">
            <img src={match.home_team_logo} className="w-full h-full object-contain" alt="H" />
          </div>
          <span className="text-[8px] sm:text-[10px] font-bold text-gray-400 truncate w-full text-center uppercase tracking-tighter">
            {match.home_team_name}
          </span>
        </div>

        <div className="flex flex-col items-center shrink-0 px-1">
          <div className="text-xl sm:text-2xl font-black text-white flex items-center gap-1.5">
            <span>{getScore(match.homeTeamScore)}</span>
            <span className="text-gray-700">-</span>
            <span>{getScore(match.awayTeamScore)}</span>
          </div>
          <span className="text-[7px] sm:text-[8px] font-black text-[#ffaa00]/80 mt-1 whitespace-nowrap uppercase tracking-tighter">
            {formatDateTime(match.match_time)}
          </span>
        </div>

        <div className="flex flex-col items-center flex-1 min-w-0">
          <div className="w-8 h-8 sm:w-10 sm:h-10 flex items-center justify-center p-1 bg-white/5 rounded-lg mb-2">
            <img src={match.away_team_logo} className="w-full h-full object-contain" alt="A" />
          </div>
          <span className="text-[8px] sm:text-[10px] font-bold text-gray-400 truncate w-full text-center uppercase tracking-tighter">
            {match.away_team_name}
          </span>
        </div>
      </div>
    </div>
  );
};

export default MatchCard;
