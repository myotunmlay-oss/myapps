
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { getDatabase, ref, onValue, serverTimestamp, set, update, get, onDisconnect } from 'firebase/database';
import { Match, AppSettings, UserAccount, Server } from '../types';
import MatchCard from '../components/MatchCard';
import VideoPlayer from '../components/VideoPlayer';

interface UserPageProps {
  themeClasses: { 
    bodyBg: string;
    navBg: string;
    cardBg: string; 
    innerBg: string; 
    matchCardBg: string; 
    matchCardHoverBg: string; 
    matchCardTeamLogoGradFrom: string; 
    matchCardTeamLogoGradTo: string;
    errorOverlayBg: string;
    playerHeaderGradFrom: string;
    playerHeaderGradTo: string;
  };
  settings: Partial<AppSettings>;
}

const SOURCE1_URL = 'https://allfootball.myotunmlay.workers.dev/';
const SOURCE2_URL = 'https://mytv.myotunmlay.workers.dev/';
const RESTRICTED_PATTERNS: string[] = [];

const UserPage: React.FC<UserPageProps> = ({ themeClasses, settings }) => {
  const [matches1, setMatches1] = useState<Match[]>([]);
  const [matches2, setMatches2] = useState<Match[]>([]);
  const [activeSource, setActiveSource] = useState<'match1' | 'match2'>('match1');
  const [loading, setLoading] = useState(true);
  const [activeMatch, setActiveMatch] = useState<Match | null>(null);
  const [currentUrl, setCurrentUrl] = useState<string | null>(null);
  const [viewerCount, setViewerCount] = useState<number>(0);
  const [currentTime, setCurrentTime] = useState(Date.now());
  
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [loginCode, setLoginCode] = useState('');
  const [loginError, setLoginError] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);
  const [userAccount, setUserAccount] = useState<UserAccount | null>(null);

  const [isRefreshing, setIsRefreshing] = useState(false);
  const [refreshCountdown, setRefreshCountdown] = useState<number>(0);
  
  const [deviceId] = useState(() => {
    let id = localStorage.getItem('mytv_device_id');
    if (!id) { id = 'dev_' + Math.random().toString(36).substr(2, 9); localStorage.setItem('mytv_device_id', id); }
    return id;
  });

  const initialLoadRef = useRef(true);

  // Update current time every second for countdowns
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);

  const translations = {
    en: {
      globalFeed: "GLOBAL FEED",
      expiry: "EXPIRY:",
      live: "LIVE",
      watching: "WATCHING",
      liveNodes: "LIVE NODES",
      noFeeds: "No Active Feeds",
      chooseNode: "CHOOSE A NODE",
      feedActive: "FEED ACTIVE",
      liveStream: "LIVE STREAM",
      channel: "CHANNEL",
      sponsored: "Sponsored Content",
      secureConnection: "SECURE CONNECTION",
      premiumGateway: "Premium Gateway",
      enterCode: "ENTER CODE",
      startSession: "START SESSION",
      syncing: "SYNCING FEED...",
      cooldown: "COOLDOWN:",
      readyUpdate: "READY TO UPDATE",
      refreshFeed: "REFRESH FEED",
      expired: "Expired",
      invalidCode: "Invalid Code",
      deviceLimitReached: "Device limit reached (Reset required)",
      error: "Error",
      awaitingFeed: "Awaiting Feed...",
      booting: "Booting Infrastructure...",
      kickoffIn: "KICK-OFF IN",
      matchFinished: "MATCH FINISHED",
      finalScore: "FINAL SCORE",
      match1: "MATCH 1",
      match2: "MATCH 2"
    },
    my: {
      globalFeed: "ကမ္ဘာလုံးဆိုင်ရာ ထုတ်လွှင့်မှု",
      expiry: "သက်တမ်းကုန်ရက်:",
      live: "တိုက်ရိုက်",
      watching: "ကြည့်ရှုနေသူ",
      liveNodes: "လိုင်းများ",
      noFeeds: "ထုတ်လွှင့်မှု မရှိသေးပါ",
      chooseNode: "လိုင်းတစ်ခု ရွေးချယ်ပါ",
      feedActive: "ထုတ်လွှင့်နေဆဲ",
      liveStream: "တိုက်ရိုက်ကြည့်ရှုရန်",
      channel: "ချန်နယ်",
      sponsored: "ကြော်ငြာများ",
      secureConnection: "လုံခြုံစိတ်ချရသော ဆက်သွယ်မှု",
      premiumGateway: "ပရီမီယံ ဝင်ပေါက်",
      enterCode: "ကုဒ်ရိုက်ထည့်ပါ",
      startSession: "စတင်အသုံးပြုမည်",
      syncing: "အချက်အလက်ယူနေသည်...",
      cooldown: "စောင့်ဆိုင်းရန်:",
      readyUpdate: "အသစ်ယူရန် အဆင်သင့်",
      refreshFeed: "အချက်အလက်အသစ်ယူရန်",
      expired: "သက်တမ်းကုန်ဆုံးပါပြီ",
      invalidCode: "မှားယွင်းနေပါသည်",
      deviceLimitReached: "ဖုန်းအရေအတွက်ပြည့်သွားပါပြီ (Reset လုပ်ပေးရန် လိုအပ်သည်)",
      error: "အမှားအယွင်းရှိပါသည်",
      awaitingFeed: "စောင့်ဆိုင်းနေသည်...",
      booting: "စနစ် စတင်နေသည်...",
      kickoffIn: "ပွဲစတင်ရန် ကျန်ရှိချိန်",
      matchFinished: "ပွဲစဉ်ပြီးဆုံးပြီဖြစ်ကြောင်း",
      finalScore: "ရလဒ်",
      match1: "MATCH 1",
      match2: "MATCH 2"
    }
  };

  const t = useMemo(() => {
    const lang = (settings && settings.app_language) || 'my';
    return translations[lang] || translations.my;
  }, [settings?.app_language]);

  const adminClicksRef = useRef(0);
  const adminClickTimeoutRef = useRef<number | null>(null);
  const handleAdminShortcut = (e: React.MouseEvent) => {
    e.stopPropagation();
    adminClicksRef.current++;
    if (adminClicksRef.current >= 5) { adminClicksRef.current = 0; window.location.hash = '#admin'; return; }
    if (adminClickTimeoutRef.current) window.clearTimeout(adminClickTimeoutRef.current);
    adminClickTimeoutRef.current = window.setTimeout(() => { adminClicksRef.current = 0; }, 3000); 
  };

  useEffect(() => {
    const timer = setInterval(() => {
      const lastSync = (settings && settings.last_sync_time) || 0;
      const intervalMs = ((settings && settings.sync_interval) || 10) * 60000;
      const elapsed = Date.now() - lastSync;
      const remaining = Math.max(0, intervalMs - elapsed);
      setRefreshCountdown(Math.floor(remaining / 1000));
    }, 1000);
    return () => clearInterval(timer);
  }, [settings?.last_sync_time, settings?.sync_interval]);

  const sortMatches = (list: Match[]) => {
    const now = Date.now();
    return list.sort((a: Match, b: Match) => {
      const timeA = (Number(a.match_time) || 0) * 1000;
      const timeB = (Number(b.match_time) || 0) * 1000;
      
      const isLiveA = now >= timeA && now < (timeA + 150 * 60 * 1000);
      const isLiveB = now >= timeB && now < (timeB + 150 * 60 * 1000);
      
      if (isLiveA && !isLiveB) return -1;
      if (!isLiveA && isLiveB) return 1;
      
      const isUpcomingA = now < timeA;
      const isUpcomingB = now < timeB;
      
      if (isUpcomingA && !isUpcomingB) return -1;
      if (!isUpcomingA && isUpcomingB) return 1;
      
      if (isUpcomingA && isUpcomingB) return timeA - timeB; 
      return timeB - timeA; 
    });
  };

  const fetchMatchesFromWorker = async (silent = false) => {
    if (!silent) setIsRefreshing(true);
    try {
      const db = getDatabase();
      const fbSnapshot = await get(ref(db, 'matches'));
      const fbMatches = fbSnapshot.val() || {};

      // Source 1
      const res1 = await fetch(`${SOURCE1_URL}?t=${Date.now()}`);
      const json1 = await res1.json();
      const raw1 = Object.values(json1.data || {});
      const sanitized1 = raw1.filter((m: any) => m && m.matchId).map((m: any) => {
        const matchId = String(m.matchId);
        const existing = fbMatches[matchId];
        const mapped = {
          match_id: m.matchId,
          home_team_name: m.homeTeamNameEn || m.homeTeamName,
          home_team_logo: m.homeTeamLogo,
          away_team_name: m.awayTeamNameEn || m.awayTeamName,
          away_team_logo: m.awayTeamLogo,
          match_time: m.matchTime,
          league_name: m.competitionNameEn || m.competitionName,
          homeTeamScore: m.homeScore?.[0] || 0,
          awayTeamScore: m.awayScore?.[0] || 0,
          servers: (m.anchorAppointmentVoList || []).map((anchor: any) => ({
            name: anchor.nickName || 'Server',
            url: anchor.playStreamAddress2 || anchor.playStreamAddress
          })).filter((s: any) => s.url)
        };
        const final = existing ? { ...mapped, ...existing } : mapped;
        final.servers = (final.servers || []).filter((s: any) => s && s.url && !RESTRICTED_PATTERNS.some(p => s.url.includes(p)));
        return final as Match;
      }).filter((m: Match) => m.servers && m.servers.length > 0);

      // Source 2
      const res2 = await fetch(`${SOURCE2_URL}?t=${Date.now()}`);
      const json2 = await res2.json();
      const raw2 = json2.matches || [];
      const sanitized2 = raw2.map((m: any, idx: number) => {
        const matchId = `s2_${idx}_${m.match_time}`;
        const existing = fbMatches[matchId];
        const mapped = {
          match_id: matchId,
          home_team_name: m.home_team_name,
          home_team_logo: m.home_team_logo,
          away_team_name: m.away_team_name,
          away_team_logo: m.away_team_logo,
          match_time: m.match_time,
          league_name: m.league_name,
          homeTeamScore: m.homeTeamScore || 0,
          awayTeamScore: m.awayTeamScore || 0,
          servers: (m.servers || []).map((s: any) => ({ name: s.name, url: s.url }))
        };
        const final = existing ? { ...mapped, ...existing } : mapped;
        final.servers = (final.servers || []).filter((s: any) => s && s.url && !RESTRICTED_PATTERNS.some(p => s.url.includes(p)));
        return final as Match;
      }).filter((m: Match) => m.servers && m.servers.length > 0);

      const sorted1 = sortMatches(sanitized1);
      const sorted2 = sortMatches(sanitized2);

      setMatches1(sorted1);
      setMatches2(sorted2);

      if (initialLoadRef.current) {
        if (sorted1.length > 0) handleMatchClick(sorted1[0]);
        else if (sorted2.length > 0) handleMatchClick(sorted2[0]);
        initialLoadRef.current = false;
        setLoading(false);
      }
      if (!silent) await update(ref(db, 'settings'), { last_sync_time: Date.now() });
    } catch (e) { 
        console.error("Worker fetch failed", e); 
        setLoading(false);
    } finally {
      if (!silent) setIsRefreshing(false);
    }
  };

  useEffect(() => {
    const db = getDatabase();
    const myPresenceRef = ref(db, `presence/${deviceId}`);
    set(myPresenceRef, serverTimestamp());
    onDisconnect(myPresenceRef).remove();
    onValue(ref(db, 'presence'), (snapshot) => setViewerCount(snapshot.exists() ? Object.keys(snapshot.val()).length : 0));
    const savedCode = localStorage.getItem('mytv_login_code');
    if (savedCode) validateLoginCode(savedCode); else setLoading(false);
    fetchMatchesFromWorker(true);
  }, [deviceId]);

  useEffect(() => {
    let intervalId: number | null = null;
    if (settings && settings.auto_sync_enabled && settings.sync_interval) {
      const ms = settings.sync_interval * 60000;
      intervalId = window.setInterval(() => fetchMatchesFromWorker(true), ms);
    }
    return () => { if (intervalId) clearInterval(intervalId); };
  }, [settings?.auto_sync_enabled, settings?.sync_interval]);

  const validateLoginCode = async (code: string) => {
    setIsVerifying(true); setLoginError('');
    const db = getDatabase();
    try {
      const snapshot = await get(ref(db, `users/${code}`));
      if (snapshot.exists()) {
        const userData = snapshot.val() as UserAccount;
        if (userData.expiry < Date.now()) { 
          setLoginError(t.expired); localStorage.removeItem('mytv_login_code'); setIsLoggedIn(false); return; 
        }
        const activeDevices = userData.activeDevices || {};
        const deviceCount = Object.keys(activeDevices).length;
        if (!activeDevices[deviceId]) {
          if (deviceCount >= (userData.deviceLimit || 1)) {
            setLoginError(t.deviceLimitReached); setIsLoggedIn(false); return;
          }
          await update(ref(db, `users/${code}/activeDevices`), { [deviceId]: Date.now() });
        }
        localStorage.setItem('mytv_login_code', code); setUserAccount(userData); setIsLoggedIn(true);
      } else { setLoginError(t.invalidCode); setIsLoggedIn(false); }
    } catch (e) { setLoginError(t.error); } finally { setIsVerifying(false); setLoading(false); }
  };

  const handleMatchClick = (match: Match) => {
    if (!match) return;
    const validServers = (match.servers || []).filter(s => s && s.url);
    if (validServers.length > 0) { 
      setCurrentUrl(null); 
      setActiveMatch(match); 
      setTimeout(() => setCurrentUrl(validServers[0].url), 100); 
    }
  };

  const formatDateTime = (timestamp: any) => {
    const ts = Number(timestamp);
    if (isNaN(ts) || ts === 0) return "LIVE";
    const date = new Date(ts * 1000);
    return `${date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short' })} | ${date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true })}`;
  };

  const getMatchStatus = (match: Match) => {
    if (!match) return null;
    const matchStart = (Number(match.match_time) || 0) * 1000;
    const now = currentTime;
    const matchEnd = matchStart + (150 * 60 * 1000); 

    if (now < matchStart) return 'upcoming';
    if (now >= matchStart && now < matchEnd) return 'live';
    return 'finished';
  };

  const getCountdown = (startTime: any) => {
    const ts = Number(startTime);
    if (isNaN(ts)) return "00:00:00";
    const diff = (ts * 1000) - currentTime;
    if (diff <= 0) return "00:00:00";
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const mins = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    const secs = Math.floor((diff % (1000 * 60)) / 1000);
    return `${hours.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const isAccessAllowed = isLoggedIn || (settings && settings.free_mode);

  if (loading) return (
    <div className="fixed inset-0 bg-[#080808] flex items-center justify-center flex-col gap-4">
      <div className="w-10 h-10 border-4 border-[#ffaa00]/10 border-t-[#ffaa00] rounded-full animate-spin"></div>
      <p className="text-[9px] font-black text-gray-500 uppercase tracking-widest">{t.booting}</p>
    </div>
  );

  const matchStatus = activeMatch ? getMatchStatus(activeMatch) : null;
  const currentMatches = activeSource === 'match1' ? matches1 : matches2;

  return (
    <div className="flex flex-col h-screen bg-[#080808] text-white overflow-hidden">
      <header className="px-4 py-3 border-b border-white/5 flex items-center justify-between shrink-0 bg-[#080808] z-20">
        <div onClick={handleAdminShortcut} className="flex items-center gap-4 cursor-pointer select-none">
          <div className="flex flex-col">
            <h1 className="text-lg sm:text-xl font-black italic tracking-tighter text-white uppercase leading-none">
              {(settings && settings.branding_logo_text) || 'MYTVLIVE PREMIUM'}
            </h1>
            <div className="flex items-center gap-1.5 mt-1">
              <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></span>
              <span className="text-[8px] font-black text-green-500 uppercase tracking-widest">{t.globalFeed}</span>
            </div>
          </div>
          {userAccount && (
            <div className="flex items-center gap-2 ml-4 overflow-hidden">
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-white/5 border border-white/10 shrink-0">
                <div className="w-4 h-4 sm:w-5 sm:h-5 bg-[#ffaa00] rounded-full flex items-center justify-center text-[7px] sm:text-[9px] text-black font-black">
                  {userAccount.name.slice(0, 1).toUpperCase()}
                </div>
                <span className="text-[8px] sm:text-[10px] font-black text-white uppercase tracking-tighter truncate max-w-[60px] sm:max-w-[120px]">
                  {userAccount.name}
                </span>
              </div>
              <div className="flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-2 px-3 py-1.5 rounded-xl bg-gradient-to-r from-[#ffaa00]/20 to-transparent border border-[#ffaa00]/10 shrink-0">
                <span className="text-[7px] sm:text-[9px] font-black text-[#ffaa00] uppercase tracking-widest">{t.expiry}</span>
                <span className="text-[8px] sm:text-[10px] font-black text-white uppercase tracking-tighter italic">
                  {new Date(userAccount.expiry).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })}
                </span>
              </div>
            </div>
          )}
        </div>
        <div className="flex items-center gap-4">
           <div className="hidden sm:flex items-center gap-2 bg-white/5 px-4 py-2 rounded-lg border border-white/5">
             <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse"></span>
             <span className="text-[10px] font-black text-white">{viewerCount.toLocaleString()} {t.live}</span>
           </div>
        </div>
      </header>

      {settings && settings.show_announcement && settings.announcement_text && (
        <div className="bg-[#ffaa00]/10 border-b border-[#ffaa00]/20 py-2 overflow-hidden whitespace-nowrap z-10">
          <div className="animate-marquee inline-block">
             <span className="text-[10px] sm:text-[12px] font-black text-[#ffaa00] uppercase tracking-widest mx-4">
               {settings.announcement_text}
             </span>
          </div>
        </div>
      )}

      <div className="flex flex-1 overflow-hidden">
        {isAccessAllowed ? (
          <>
            <aside className="w-[140px] sm:w-[280px] md:w-[320px] lg:w-[360px] border-r border-white/5 overflow-y-auto flex flex-col p-2 sm:p-4 md:p-6 bg-black/40 shrink-0 scrollbar-hide">
              <div className="mb-4">
                <button 
                  onClick={() => fetchMatchesFromWorker(false)}
                  disabled={isRefreshing || refreshCountdown > 0}
                  className={`w-full group relative overflow-hidden flex flex-col items-center justify-center gap-1.5 py-4 rounded-2xl border transition-all duration-300 active:scale-95 ${
                    isRefreshing ? 'bg-white/5 border-white/10 opacity-50' : (refreshCountdown > 0 ? 'bg-white/5 border-white/10' : 'bg-gradient-to-br from-[#00ff88]/20 to-transparent border-[#00ff88]/30 hover:border-[#00ff88]/60 shadow-[0_0_20px_rgba(0,255,136,0.05)]')
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className={`text-lg ${isRefreshing ? 'animate-spin' : (refreshCountdown > 0 ? 'opacity-30' : 'animate-bounce')}`}>
                      {isRefreshing ? '🔄' : '⚡'}
                    </span>
                    <span className={`text-[11px] font-black uppercase tracking-[0.2em] ${refreshCountdown > 0 ? 'text-gray-500' : 'text-[#00ff88]'}`}>
                      {isRefreshing ? t.syncing : ((settings && settings.server_update_text) || t.refreshFeed)}
                    </span>
                  </div>
                  {refreshCountdown > 0 && <div className="text-[8px] font-black text-gray-600 uppercase tracking-widest">{t.cooldown} {refreshCountdown}S</div>}
                </button>
              </div>

              {/* Source Tabs */}
              <div className="grid grid-cols-2 gap-2 mb-6 p-1 bg-white/5 rounded-xl border border-white/5">
                 <button onClick={() => setActiveSource('match1')} className={`py-2 rounded-lg text-[9px] font-black uppercase tracking-widest transition-all ${activeSource === 'match1' ? 'bg-[#ffaa00] text-black shadow-lg shadow-[#ffaa00]/20' : 'text-gray-500 hover:text-white'}`}>
                    {t.match1}
                 </button>
                 <button onClick={() => setActiveSource('match2')} className={`py-2 rounded-lg text-[9px] font-black uppercase tracking-widest transition-all ${activeSource === 'match2' ? 'bg-[#ffaa00] text-black shadow-lg shadow-[#ffaa00]/20' : 'text-gray-500 hover:text-white'}`}>
                    {t.match2}
                 </button>
              </div>

              <div className="flex items-center justify-between mb-4 px-1">
                <h2 className="text-[8px] font-black text-gray-500 uppercase tracking-widest">{t.liveNodes}</h2>
                <div className="text-[8px] font-black text-gray-400 bg-white/5 px-2 py-0.5 rounded border border-white/5">{currentMatches.length}</div>
              </div>
              
              <div className="space-y-3 pb-20">
                {currentMatches.length > 0 ? (
                  currentMatches.map((m, idx) => (
                    <MatchCard key={m.match_id} match={m} index={idx + 1} onPlay={handleMatchClick} isActive={activeMatch?.match_id === m.match_id} themeClasses={themeClasses} />
                  ))
                ) : (
                  <div className="py-10 text-center space-y-3 opacity-20"><div className="text-4xl">📡</div><p className="text-[10px] font-black uppercase tracking-[0.2em]">{t.noFeeds}</p></div>
                )}
              </div>
            </aside>

            <main className="flex-1 overflow-y-auto bg-[#0a0a0a] p-3 sm:p-6 md:p-8 scrollbar-hide">
              <div className="max-w-4xl mx-auto space-y-6 sm:space-y-10 pb-32">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                   <div className="flex flex-col gap-1">
                     <h2 className="text-xl sm:text-3xl md:text-5xl font-black italic uppercase leading-tight tracking-tighter text-white">
                        {activeMatch ? `${activeMatch.home_team_name} VS ${activeMatch.away_team_name}` : t.chooseNode}
                     </h2>
                     <div className="flex items-center gap-3 mt-2">
                        <div className="px-3 py-1 rounded-full bg-white/5 border border-white/10 flex items-center">
                          <span className="text-[9px] sm:text-[12px] md:text-[14px] font-black text-[#ffaa00] uppercase tracking-widest">
                            {activeMatch?.league_name || t.feedActive}
                          </span>
                        </div>
                        {activeMatch && (
                          <div className="px-3 py-1 rounded-full bg-[#ffaa00]/10 border border-[#ffaa00]/20 flex items-center gap-2">
                            <span className="text-[10px] sm:text-[13px] md:text-[15px] font-black text-white uppercase tracking-widest italic leading-none">
                              {formatDateTime(activeMatch.match_time)}
                            </span>
                            <span className={`w-2 h-2 rounded-full animate-pulse ${matchStatus === 'live' ? 'bg-red-500' : 'bg-[#ffaa00]'}`}></span>
                          </div>
                        )}
                     </div>
                   </div>
                   <div className="bg-red-600 px-4 py-2 rounded-lg text-[8px] sm:text-[10px] font-black uppercase tracking-widest animate-pulse shadow-lg shadow-red-600/20 w-fit">
                      {matchStatus === 'live' ? t.liveStream : (matchStatus === 'upcoming' ? 'UPCOMING' : 'FINISHED')}
                   </div>
                </div>

                <div className="w-full aspect-video rounded-2xl sm:rounded-[2.5rem] overflow-hidden border border-white/10 shadow-2xl relative bg-[#060606]">
                  {activeMatch ? (
                    <>
                      {matchStatus === 'live' ? (
                        currentUrl ? (
                          <VideoPlayer 
                            key={currentUrl} options={{ autoplay: true }} currentUrl={currentUrl} themeClasses={themeClasses} viewerCount={viewerCount} 
                            showBrandingLogo={settings?.show_branding_logo} logoText={settings?.branding_logo_text} logoUrl={settings?.branding_logo_url}
                            logoSize={settings?.branding_logo_size} logoPosition={settings?.branding_logo_position} logoOffsetX={settings?.branding_logo_offset_x}
                            logoOffsetY={settings?.branding_logo_offset_y} ads={settings?.custom_ads} adsWidth={settings?.ads_banner_width} adsBottom={settings?.ads_banner_offset_y}
                          />
                        ) : (
                          <div className="absolute inset-0 flex items-center justify-center flex-col gap-4 bg-[#080808]">
                            <div className="w-10 h-10 border-[3px] border-white/5 border-t-[#ffaa00] rounded-full animate-spin"></div>
                            <p className="text-[8px] font-black text-gray-600 uppercase tracking-widest">{t.awaitingFeed}</p>
                          </div>
                        )
                      ) : matchStatus === 'upcoming' ? (
                        <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/40 backdrop-blur-sm p-6 text-center">
                          <div className="flex items-center gap-8 mb-8 scale-75 sm:scale-100">
                             <img src={activeMatch.home_team_logo} className="w-20 h-20 object-contain drop-shadow-2xl" />
                             <span className="text-4xl font-black italic text-gray-700">VS</span>
                             <img src={activeMatch.away_team_logo} className="w-20 h-20 object-contain drop-shadow-2xl" />
                          </div>
                          <div className="space-y-2">
                             <p className="text-[#00ff88] text-[10px] font-black uppercase tracking-[0.4em]">{t.kickoffIn}</p>
                             <h3 className="text-4xl sm:text-7xl font-black text-white tracking-tighter tabular-nums">
                               {getCountdown(activeMatch.match_time)}
                             </h3>
                          </div>
                          <div className="mt-8 px-6 py-2 bg-white/5 rounded-full border border-white/10 text-[9px] font-black text-gray-400 uppercase tracking-widest">
                            {formatDateTime(activeMatch.match_time)}
                          </div>
                        </div>
                      ) : (
                        <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/80 backdrop-blur-xl p-10 text-center animate-in fade-in duration-700">
                           <div className="w-20 h-20 bg-white/5 rounded-full flex items-center justify-center mb-8 border border-white/10 shadow-[0_0_30px_rgba(255,255,255,0.05)]">
                              <span className="text-4xl animate-bounce">🏁</span>
                           </div>
                           <h3 className="text-xl sm:text-2xl font-black text-white uppercase italic tracking-tighter mb-8 leading-relaxed">
                             {t.matchFinished}
                           </h3>
                           
                           <div className="w-full max-w-lg bg-white/5 px-4 sm:px-10 py-8 rounded-[2.5rem] border border-white/10 flex items-center justify-between shadow-2xl relative overflow-hidden group">
                              <div className="absolute inset-0 bg-gradient-to-r from-[#00ff88]/5 to-transparent pointer-events-none"></div>
                              
                              <div className="flex flex-col items-center gap-3 relative z-10 flex-1">
                                <div className="w-14 h-14 sm:w-16 sm:h-16 bg-black/40 rounded-2xl p-2.5 border border-white/5 shadow-lg group-hover:scale-110 transition-transform">
                                  <img src={activeMatch.home_team_logo} className="w-full h-full object-contain" />
                                </div>
                                <span className="text-[10px] font-black text-gray-400 uppercase tracking-tighter text-center line-clamp-1">{activeMatch.home_team_name}</span>
                              </div>

                              <div className="flex flex-col items-center gap-1 relative z-10 px-4">
                                <div className="text-4xl sm:text-6xl font-black text-[#00ff88] tracking-tighter flex items-center gap-2 drop-shadow-[0_0_15px_rgba(0,255,136,0.3)]">
                                  <span>{activeMatch.homeTeamScore || 0}</span>
                                  <span className="text-white/20">-</span>
                                  <span>{activeMatch.awayTeamScore || 0}</span>
                                </div>
                                <span className="text-[8px] font-black text-gray-500 uppercase tracking-[0.4em]">{t.finalScore}</span>
                              </div>

                              <div className="flex flex-col items-center gap-3 relative z-10 flex-1">
                                <div className="w-14 h-14 sm:w-16 sm:h-16 bg-black/40 rounded-2xl p-2.5 border border-white/5 shadow-lg group-hover:scale-110 transition-transform">
                                  <img src={activeMatch.away_team_logo} className="w-full h-full object-contain" />
                                </div>
                                <span className="text-[10px] font-black text-gray-400 uppercase tracking-tighter text-center line-clamp-1">{activeMatch.away_team_name}</span>
                              </div>
                           </div>
                           
                           <button 
                             onClick={() => fetchMatchesFromWorker(false)}
                             className="mt-10 text-[9px] font-black text-gray-500 uppercase tracking-[0.3em] hover:text-[#00ff88] transition-colors flex items-center gap-2"
                           >
                             <span className="w-1.5 h-1.5 rounded-full bg-gray-700"></span>
                             REFRESH TO UPDATE RESULTS
                           </button>
                        </div>
                      )}
                    </>
                  ) : (
                    <div className="absolute inset-0 flex items-center justify-center flex-col gap-4 bg-[#080808]">
                      <div className="w-10 h-10 border-[3px] border-white/5 border-t-[#ffaa00] rounded-full animate-spin"></div>
                      <p className="text-[8px] font-black text-gray-600 uppercase tracking-widest">{t.awaitingFeed}</p>
                    </div>
                  )}
                </div>

                {activeMatch && matchStatus === 'live' && (
                  <div className="flex flex-wrap justify-center gap-2 sm:gap-3 py-2">
                    {(activeMatch.servers || []).filter(s => s && s.url).map((s, idx) => (
                      <button key={idx} onClick={() => setCurrentUrl(s.url)} className={`px-6 py-3 rounded-xl text-[8px] sm:text-[10px] font-black uppercase tracking-widest transition-all border ${currentUrl === s.url ? 'bg-[#ffaa00] text-black border-[#ffaa00]' : 'bg-white/5 text-gray-500 border-white/10 hover:bg-white/10'}`}>
                        {s.name || `${t.channel} ${idx + 1}`}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </main>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center p-6 bg-[#080808]">
             <div className="max-w-md w-full bg-[#0a0a0a] border border-white/5 p-10 rounded-[3rem] text-center shadow-2xl animate-in zoom-in">
                <div className="w-16 h-16 bg-[#ffaa00]/10 rounded-3xl flex items-center justify-center mx-auto mb-8 border border-[#ffaa00]/20 text-3xl">🔐</div>
                <h1 className="text-xl font-black text-white uppercase italic tracking-tighter mb-8">{t.premiumGateway}</h1>
                <input type="text" placeholder={t.enterCode} value={loginCode} onChange={e => setLoginCode(e.target.value.toUpperCase())} className="w-full bg-black/40 border border-white/10 p-6 rounded-2xl text-center font-black text-[#ffaa00] text-3xl outline-none focus:border-[#ffaa00]/30 mb-6" />
                {loginError && <p className="text-red-500 text-[10px] font-black uppercase mb-6 tracking-widest">{loginError}</p>}
                <button onClick={() => validateLoginCode(loginCode)} className="w-full py-5 bg-[#ffaa00] text-black font-black rounded-2xl uppercase tracking-[0.2em] text-xs active:scale-95 shadow-xl shadow-[#ffaa00]/10">{t.startSession}</button>
             </div>
          </div>
        )}
      </div>

      <footer className="px-4 py-2 border-t border-white/5 bg-black/80 flex items-center justify-between shrink-0 z-20">
         <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-green-500"></span>
            <span className="text-[7px] font-black text-gray-500 uppercase tracking-widest">NODE ID: {deviceId.toUpperCase()}</span>
         </div>
         <div className="text-[7px] font-black text-gray-600 uppercase tracking-widest">{t.secureConnection}</div>
      </footer>
    </div>
  );
};

export default UserPage;
