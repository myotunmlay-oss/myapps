
import React, { useState, useEffect, useRef } from 'react';
import { getDatabase, ref, onValue, update, set, push, remove, get } from 'firebase/database';
import { CURRENT_APP_VERSION } from '../constants';
import { AppSettings, Match, Server, ChatSession, UserAccount, AdBanner } from '../types';

interface AdminPageProps {
  onExit: () => void;
  themeClasses: {
    adminBg: string;
    cardBg: string;
    innerBg: string;
  };
}

const SOURCE1_URL = 'https://api12.colatv88xd.cc/api/matches';
const SOURCE2_URL = 'https://mytv.myotunmlay.workers.dev/';
const RESTRICTED_PATTERNS: string[] = [];

const AdminPage: React.FC<AdminPageProps> = ({ onExit, themeClasses }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [passwordInput, setPasswordInput] = useState('');
  const [storedPassword, setStoredPassword] = useState('1234');
  const [activeTab, setActiveTab] = useState<'dashboard' | 'matches' | 'messages' | 'users' | 'ads' | 'settings'>('dashboard');
  
  const [adminMatches, setAdminMatches] = useState<Match[]>([]);
  const [syncLoading, setSyncLoading] = useState(false);

  const [chatSessions, setChatSessions] = useState<ChatSession[]>([]);
  const [activeChatId, setActiveChatId] = useState<string | null>(null);
  const [chatInput, setChatInput] = useState('');
  const [viewerCount, setViewerCount] = useState(0);

  const [users, setUsers] = useState<UserAccount[]>([]);
  const [expiryDays, setExpiryDays] = useState(30); 
  const [newUser, setNewUser] = useState<Partial<UserAccount>>({ name: '', code: '', deviceLimit: 1 });
  const [editingUserCode, setEditingUserCode] = useState<string | null>(null);

  const [settings, setSettings] = useState<Partial<AppSettings>>({});
  
  const [newAd, setNewAd] = useState<AdBanner>({ image: '', link: '' });
  const [editingAdIndex, setEditingAdIndex] = useState<number | null>(null);

  const [editingMatch, setEditingMatch] = useState<Match | null>(null);

  const chatScrollRef = useRef<HTMLDivElement>(null);
  const lastKnownSyncRef = useRef<number>(0);

  const generate6DigitCode = () => Math.floor(100000 + Math.random() * 900000).toString();

  const sortMatches = (list: Match[]) => {
    const now = Date.now();
    return list.sort((a: Match, b: Match) => {
      const timeA = (Number(a.match_time) || 0) * 1000;
      const timeB = (Number(b.match_time) || 0) * 1000;
      const isLiveA = now >= timeA && now < (timeA + 150 * 60 * 1000);
      const isLiveB = now >= timeB && now < (timeB + 150 * 60 * 1000);
      if (isLiveA && !isLiveB) return -1;
      if (!isLiveA && isLiveB) return 1;
      const isUpcomingA = now < timeA;
      const isUpcomingB = now < timeB;
      if (isUpcomingA && !isUpcomingB) return -1;
      if (!isUpcomingA && isUpcomingB) return 1;
      if (isUpcomingA && isUpcomingB) return timeA - timeB; 
      return timeB - timeA; 
    });
  };

  const fetchMatchesFromWorker = async (silent = false) => {
    if (!silent) setSyncLoading(true);
    try {
      const db = getDatabase();
      const fbSnapshot = await get(ref(db, 'matches'));
      const fbMatches = fbSnapshot.val() || {};

      // Source 1
      const res1 = await fetch(`${SOURCE1_URL}?t=${Date.now()}`);
      const json1 = await res1.json();
      const raw1 = Object.values(json1.data || {});
      const sanitized1 = raw1.filter((m: any) => m && m.matchId).map((m: any) => {
        const matchId = String(m.matchId);
        const existing = fbMatches[matchId];
        const mapped = {
          match_id: m.matchId,
          home_team_name: m.homeTeamNameEn || m.homeTeamName,
          home_team_logo: m.homeTeamLogo,
          away_team_name: m.awayTeamNameEn || m.awayTeamName,
          away_team_logo: m.awayTeamLogo,
          match_time: m.matchTime,
          league_name: m.competitionNameEn || m.competitionName,
          homeTeamScore: m.homeScore?.[0] || 0,
          awayTeamScore: m.awayScore?.[0] || 0,
          servers: (m.anchorAppointmentVoList || []).map((anchor: any) => ({
            name: anchor.nickName || 'Server',
            url: anchor.playStreamAddress2 || anchor.playStreamAddress
          })).filter((s: any) => s.url)
        };
        const final = existing ? { ...mapped, ...existing } : mapped;
        final.servers = (final.servers || []).filter((s: any) => s && s.url && !RESTRICTED_PATTERNS.some(p => s.url.includes(p)));
        return final as Match;
      }).filter((m: Match) => m.servers && m.servers.length > 0);

      // Source 2
      const res2 = await fetch(`${SOURCE2_URL}?t=${Date.now()}`);
      const json2 = await res2.json();
      const raw2 = json2.matches || [];
      const sanitized2 = raw2.map((m: any, idx: number) => {
        const matchId = `s2_${idx}_${m.match_time}`;
        const existing = fbMatches[matchId];
        const mapped = {
          match_id: matchId,
          home_team_name: m.home_team_name,
          home_team_logo: m.home_team_logo,
          away_team_name: m.away_team_name,
          away_team_logo: m.away_team_logo,
          match_time: m.match_time,
          league_name: m.league_name,
          homeTeamScore: m.homeTeamScore || 0,
          awayTeamScore: m.awayTeamScore || 0,
          servers: (m.servers || []).map((s: any) => ({ name: s.name, url: s.url }))
        };
        const final = existing ? { ...mapped, ...existing } : mapped;
        final.servers = (final.servers || []).filter((s: any) => s && s.url && !RESTRICTED_PATTERNS.some(p => s.url.includes(p)));
        return final as Match;
      }).filter((m: Match) => m.servers && m.servers.length > 0);

      const allCombined = sortMatches([...sanitized1, ...sanitized2]);
      setAdminMatches(allCombined);
      
      if (!silent) {
        await update(ref(db, 'settings'), { last_sync_time: Date.now() });
      }
    } catch (e) {
      console.error(e);
      if (!silent) alert('Sync Error');
    } finally {
      if (!silent) setSyncLoading(false);
    }
  };

  useEffect(() => {
    const db = getDatabase();
    onValue(ref(db, 'settings'), (snapshot) => {
      const data = snapshot.val();
      if (data) {
        if (data.admin_password) setStoredPassword(data.admin_password);
        setSettings(data);

        if (data.last_sync_time && data.last_sync_time > lastKnownSyncRef.current) {
          lastKnownSyncRef.current = data.last_sync_time;
          fetchMatchesFromWorker(true);
        }
      }
    });

    onValue(ref(db, 'chats'), (snapshot) => {
      const data = snapshot.val();
      if (data) setChatSessions(Object.entries(data).map(([userId, val]: any) => ({ ...val, userId })).sort((a, b) => b.lastTimestamp - a.lastTimestamp));
      else setChatSessions([]);
    });

    onValue(ref(db, 'users'), (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.val();
        setUsers((Object.values(data) as UserAccount[]).sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0)));
      } else {
        setUsers([]);
      }
    });

    onValue(ref(db, 'presence'), (snapshot) => {
      setViewerCount(snapshot.exists() ? Object.keys(snapshot.val()).length : 0);
    });
  }, []);

  useEffect(() => {
    if (chatScrollRef.current) {
      chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight;
    }
  }, [activeChatId, chatSessions]);

  const handleUpdateSetting = async (key: string, value: any) => {
    const db = getDatabase();
    await update(ref(db, 'settings'), { [key]: value });
  };

  const handleAddUser = async () => {
    if (!newUser.name) return alert("User Name Required");
    const db = getDatabase();
    const code = newUser.code || generate6DigitCode();
    const expiry = editingUserCode ? (newUser.expiry || Date.now() + (expiryDays * 24 * 60 * 60 * 1000)) : Date.now() + (expiryDays * 24 * 60 * 60 * 1000);
    
    const userToSave = { 
      ...newUser, 
      code, 
      expiry, 
      createdAt: newUser.createdAt || Date.now() 
    };
    
    const cleanUser: any = {};
    Object.keys(userToSave).forEach(k => { 
      if((userToSave as any)[k] !== undefined) cleanUser[k] = (userToSave as any)[k]; 
    });

    await set(ref(db, `users/${code}`), cleanUser);
    setNewUser({ name: '', code: '', deviceLimit: 1 }); 
    setEditingUserCode(null);
  };

  const handleEditUser = (user: UserAccount) => {
    setNewUser(user);
    setEditingUserCode(user.code);
    setActiveTab('users');
  };

  const handleDeleteUser = async (code: string) => {
    if (!confirm(`Are you sure you want to delete user code: ${code}?`)) return;
    const db = getDatabase();
    try {
      await remove(ref(db, `users/${code}`));
      alert('User deleted successfully.');
    } catch (e) {
      alert('Error deleting user.');
    }
  };

  const handleResetUserDevices = async (code: string) => {
    if (!confirm('Reset devices for this code?')) return;
    const db = getDatabase();
    await update(ref(db, `users/${code}`), { activeDevices: null });
    alert('User devices reset successfully.');
  };

  const handleSaveAd = async () => {
    if (!newAd.image) return alert('Enter Image URL');
    const db = getDatabase();
    const ads = [...(settings.custom_ads || [])];
    if (editingAdIndex !== null) { ads[editingAdIndex] = newAd; } else { ads.push(newAd); }
    await set(ref(db, 'settings/custom_ads'), ads);
    setNewAd({ image: '', link: '' }); setEditingAdIndex(null);
    alert('Banner Saved!');
  };

  const handleSendAdminMessage = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!chatInput.trim() || !activeChatId) return;
    const db = getDatabase();
    await push(ref(db, `chats/${activeChatId}/messages`), { sender: 'admin', text: chatInput.trim(), timestamp: Date.now() });
    await update(ref(db, `chats/${activeChatId}`), { lastMessage: chatInput.trim(), lastTimestamp: Date.now(), unreadUser: (chatSessions.find(s => s.userId === activeChatId)?.unreadUser || 0) + 1, unreadAdmin: 0 });
    setChatInput('');
  };

  const handleDeleteChatSession = async (userId: string) => {
    if (!confirm('Delete this chat session?')) return;
    const db = getDatabase();
    await remove(ref(db, `chats/${userId}`));
    if (activeChatId === userId) setActiveChatId(null);
  };

  const handleSaveEditedMatch = async () => {
    if (!editingMatch) return;
    const db = getDatabase();
    try {
      await set(ref(db, `matches/${editingMatch.match_id}`), {
        ...editingMatch,
        is_manual: true
      });
      setEditingMatch(null);
      fetchMatchesFromWorker(true);
      alert('Match Updated Successfully!');
    } catch (e) {
      alert('Error saving match');
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-black p-6">
        <div className="max-w-md w-full p-10 bg-[#0a0a0a] border border-white/5 rounded-[2.5rem] text-center shadow-2xl animate-in zoom-in">
          <div className="w-20 h-20 bg-[#00ff88]/10 rounded-3xl flex items-center justify-center mx-auto mb-8 border border-[#00ff88]/20 text-3xl">🛡️</div>
          <h2 className="text-2xl font-black mb-10 text-white uppercase italic tracking-tighter">Admin Access</h2>
          <form onSubmit={e => { e.preventDefault(); if (passwordInput === storedPassword) setIsAuthenticated(true); else alert('Wrong PW'); }} className="space-y-6">
            <input type="password" value={passwordInput} onChange={e => setPasswordInput(e.target.value)} className="w-full bg-black/40 border border-white/10 p-5 rounded-2xl text-center text-[#00ff88] text-xl outline-none focus:border-[#00ff88]/40" placeholder="••••" />
            <button type="submit" className="w-full bg-[#00ff88] text-black font-black py-5 rounded-2xl shadow-xl active:scale-95 transition-all uppercase tracking-widest">Login</button>
            <button type="button" onClick={onExit} className="text-gray-600 text-[10px] uppercase mt-4 tracking-widest hover:text-white">Exit System</button>
          </form>
        </div>
      </div>
    );
  }

  const navItems = [
    { id: 'dashboard', label: 'DA...', icon: '📊' },
    { id: 'matches', label: 'LI...', icon: '⚽' },
    { id: 'messages', label: 'IN...', icon: '💬', badge: chatSessions.some(s => s.unreadAdmin > 0) },
    { id: 'users', label: 'US...', icon: '👥' },
    { id: 'ads', label: 'BA...', icon: '📢' },
    { id: 'settings', label: 'SE...', icon: '⚙️' }
  ];

  const SettingToggle = ({ label, subLabel, value, onChange }: { label: string, subLabel?: string, value: boolean, onChange: (v: boolean) => void }) => (
    <div className="flex items-center justify-between py-2">
      <div className="flex flex-col">
        <span className="text-[10px] font-black uppercase text-gray-300 tracking-widest">{label}</span>
        {subLabel && <span className="text-[8px] font-bold text-[#00ff88] uppercase tracking-tighter mt-0.5">{subLabel}</span>}
      </div>
      <button 
        onClick={() => onChange(!value)}
        className={`w-12 h-6 rounded-full relative transition-all duration-300 ${value ? 'bg-[#00ff88] shadow-[0_0_10px_rgba(0,255,136,0.3)]' : 'bg-gray-700'}`}
      >
        <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all duration-300 ${value ? 'left-7' : 'left-1'}`}></div>
      </button>
    </div>
  );

  return (
    <div className="flex h-screen bg-black text-white overflow-hidden">
      <aside className="w-20 md:w-64 border-r border-white/5 bg-[#0a0a0a] flex flex-col p-4 md:p-6 space-y-10 shrink-0">
        <div className="flex items-center justify-center md:justify-start gap-3 px-2">
            <div className="w-10 h-10 bg-[#00ff88] rounded-xl flex items-center justify-center text-black font-black text-xl">M</div>
            <h1 className="hidden md:block text-lg font-black italic text-[#00ff88] uppercase tracking-tighter">MyTV Admin</h1>
        </div>
        <nav className="flex-1 space-y-4 overflow-y-auto pr-0 scrollbar-hide">
          {navItems.map(item => (
            <button key={item.id} onClick={() => { setActiveTab(item.id as any); setActiveChatId(null); setEditingAdIndex(null); }} className={`w-full flex flex-col items-center gap-1 py-3 transition-all relative ${activeTab === item.id ? 'text-[#00ff88]' : 'text-gray-500 hover:text-white'}`}>
              <span className={`text-2xl transition-all ${activeTab === item.id ? 'scale-110' : ''}`}>{item.icon}</span>
              <span className="text-[7px] md:text-[8px] font-black uppercase tracking-widest">{item.label}</span>
              {item.badge && <span className="absolute top-2 right-4 w-1.5 h-1.5 bg-red-500 rounded-full border border-black animate-pulse"></span>}
              {activeTab === item.id && <div className="absolute left-0 w-1 h-8 bg-[#00ff88] rounded-r-full"></div>}
            </button>
          ))}
        </nav>
        <button onClick={onExit} className="flex flex-col items-center gap-1 py-5 text-red-500 text-[8px] font-black uppercase mt-auto">
          <span className="text-xl">🚪</span><span>EXIT</span>
        </button>
      </aside>

      <main className="flex-1 flex flex-col min-w-0 bg-[#060606] relative">
        <header className="flex justify-between items-center p-8 pb-4 shrink-0">
           <h2 className="text-2xl font-black uppercase italic tracking-tighter">{activeTab.toUpperCase()}</h2>
           <div className="flex items-center gap-4">
              <div className="bg-[#0a0a0a] px-4 py-2 rounded-xl border border-white/5 flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-[#00ff88] animate-pulse"></span>
                <span className="text-[#00ff88] font-black text-sm">{viewerCount}</span>
                <span className="text-[8px] text-gray-500 uppercase font-black">ACTIVE</span>
              </div>
           </div>
        </header>

        <div className="flex-1 overflow-y-auto px-8 pb-32 scrollbar-hide">
          {activeTab === 'dashboard' && (
             <div className="space-y-8 animate-in slide-in-from-bottom-4">
                <div className="bg-gradient-to-br from-[#00ff88]/20 via-[#00ff88]/5 to-transparent border border-[#00ff88]/30 p-10 rounded-[3rem] flex flex-col items-center justify-center gap-8 shadow-2xl relative overflow-hidden group">
                   <div className="absolute top-0 right-0 w-64 h-64 bg-[#00ff88]/5 rounded-full blur-[100px] pointer-events-none"></div>
                   
                   <div className="flex flex-col gap-3 text-center relative z-10">
                      <h3 className="text-2xl font-black text-white uppercase italic tracking-tight leading-relaxed">
                        {settings.server_update_text || 'ဆာဗာအသစ်ယူရန် နှိပ်ပါ'}
                      </h3>
                      <p className="text-[10px] text-gray-400 font-bold uppercase tracking-[0.2em] opacity-60">
                        SYNCHRONIZE MATCHES DIRECTLY FROM THE EXTERNAL WORKER URL.
                      </p>
                   </div>

                   <div className="w-full max-sm flex flex-col items-center gap-6 relative z-10">
                      <button 
                        onClick={() => fetchMatchesFromWorker(false)} 
                        disabled={syncLoading} 
                        className="w-full bg-[#00ff88] hover:bg-[#00cc6e] text-black font-black px-14 py-6 rounded-3xl shadow-xl shadow-[#00ff88]/20 transition-all active:scale-95 text-sm uppercase tracking-widest disabled:opacity-50"
                      >
                        {syncLoading ? 'SYNCHRONIZING...' : (settings.server_update_text || 'ဆာဗာအသစ်ယူရန် နှိပ်ပါ')}
                      </button>

                      <div className="w-full grid grid-cols-2 gap-4">
                        <div className="bg-black/40 border border-white/5 p-4 rounded-2xl flex flex-col gap-3">
                           <div className="flex items-center justify-between">
                             <span className="text-[9px] font-black text-gray-400 uppercase tracking-widest">AUTO SYNC</span>
                             <button 
                               onClick={() => handleUpdateSetting('auto_sync_enabled', !settings.auto_sync_enabled)}
                               className={`w-10 h-5 rounded-full relative transition-all ${settings.auto_sync_enabled ? 'bg-[#00ff88]' : 'bg-gray-700'}`}
                             >
                                <div className={`absolute top-1 w-3 h-3 rounded-full bg-white transition-all ${settings.auto_sync_enabled ? 'left-6' : 'left-1'}`}></div>
                             </button>
                           </div>
                           <p className="text-[7px] text-gray-500 font-bold uppercase">Automate worker refreshes</p>
                        </div>

                        <div className="bg-black/40 border border-white/5 p-4 rounded-2xl flex flex-col gap-1">
                           <span className="text-[9px] font-black text-gray-400 uppercase tracking-widest">INTERVAL (MIN)</span>
                           <input 
                              type="number" 
                              min="1"
                              value={settings.sync_interval || 5} 
                              onChange={(e) => handleUpdateSetting('sync_interval', parseInt(e.target.value) || 1)}
                              className="bg-transparent text-[#00ff88] font-black text-xl outline-none w-full"
                           />
                        </div>
                      </div>
                   </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                    <div className="bg-[#0a0a0a] p-8 rounded-[2rem] border border-white/5 h-44 flex flex-col justify-between">
                       <h3 className="text-[11px] font-black text-gray-500 uppercase tracking-widest">Active Streams</h3>
                       <span className="text-5xl font-black">{adminMatches.length}</span>
                    </div>
                </div>
             </div>
          )}

          {activeTab === 'matches' && (
             <div className="space-y-6 animate-in fade-in">
                <div className="flex gap-4">
                  <button onClick={() => fetchMatchesFromWorker(false)} disabled={syncLoading} className="px-10 py-4 bg-[#00ff88] text-black font-black rounded-2xl uppercase text-[11px] tracking-widest shadow-xl">{syncLoading ? 'Syncing...' : 'Worker Refresh'}</button>
                </div>
                <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
                   {adminMatches.map((m, idx) => (
                      <div key={idx} className="bg-[#0a0a0a] border border-white/5 p-6 rounded-[2rem] flex items-center justify-between group relative overflow-hidden transition-all hover:border-[#00ff88]/30">
                         <div className="absolute top-0 left-0 bg-[#00ff88]/10 text-[#00ff88] font-black px-4 py-1.5 rounded-br-2xl text-[10px]">INDEX #{idx + 1}</div>
                         <div className="flex items-center gap-6 ml-10">
                            <div className="w-12 h-12 bg-white/5 rounded-xl p-2"><img src={m.home_team_logo} className="w-full h-full object-contain" /></div>
                            <div className="flex flex-col">
                               <span className="text-sm font-black uppercase">{m.home_team_name} vs {m.away_team_name}</span>
                               <span className="text-[10px] text-[#00ff88] font-bold uppercase mt-1">{m.servers?.length || 0} Relay Channels</span>
                            </div>
                            <div className="w-12 h-12 bg-white/5 rounded-xl p-2"><img src={m.away_team_logo} className="w-full h-full object-contain" /></div>
                         </div>
                         <div className="flex gap-2">
                           <button onClick={() => setEditingMatch(m)} className="bg-white/5 p-3 rounded-xl border border-white/10 text-xs font-black text-gray-400 uppercase tracking-widest hover:bg-white/10 transition-all">Edit</button>
                         </div>
                      </div>
                   ))}
                </div>
             </div>
          )}

          {activeTab === 'messages' && (
             <div className="flex h-[calc(100vh-220px)] border border-white/5 rounded-[2.5rem] overflow-hidden bg-[#0a0a0a] shadow-2xl">
                <div className="w-80 border-r border-white/5 flex flex-col bg-black/20 shrink-0">
                   <div className="p-6 border-b border-white/5 flex justify-between items-center">
                     <h3 className="text-xs font-black uppercase tracking-widest">Support Inbox</h3>
                     <span className="bg-[#00ff88] text-black text-[10px] font-black px-2.5 py-0.5 rounded-full">{chatSessions.length}</span>
                   </div>
                   <div className="flex-1 overflow-y-auto p-2 space-y-1">
                      {chatSessions.map((session) => (
                         <div key={session.userId} className="relative group">
                           <button onClick={() => { setActiveChatId(session.userId); update(ref(getDatabase(), `chats/${session.userId}`), { unreadAdmin: 0 }); }} className={`w-full flex items-center gap-4 p-4 rounded-2xl transition-all relative ${activeChatId === session.userId ? 'bg-[#00ff88]/10 ring-1 ring-[#00ff88]/20' : 'hover:bg-white/5'}`}>
                              <div className="w-10 h-10 bg-[#00ff88] rounded-full flex items-center justify-center text-black font-black text-sm">{session.userId.slice(4, 5).toUpperCase()}</div>
                              <div className="flex-1 text-left min-w-0">
                                 <p className={`text-xs font-black truncate uppercase ${activeChatId === session.userId ? 'text-[#00ff88]' : 'text-gray-200'}`}>{session.userId}</p>
                                 <p className="text-[9px] text-gray-500 truncate mt-1">{session.lastMessage}</p>
                              </div>
                              {session.unreadAdmin > 0 && <span className="absolute top-4 right-4 w-2 h-2 bg-red-500 rounded-full animate-pulse ring-2 ring-red-500/20"></span>}
                           </button>
                           <button onClick={(e) => { e.stopPropagation(); handleDeleteChatSession(session.userId); }} className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity bg-red-600 text-white w-6 h-6 rounded-full flex items-center justify-center text-[10px] hover:bg-red-500">✕</button>
                         </div>
                      ))}
                   </div>
                </div>
                <div className="flex-1 flex flex-col bg-black/30 backdrop-blur-md">
                   {activeChatId ? (
                      <>
                         <div className="p-6 border-b border-white/5 bg-[#0a0a0a]/50 flex items-center gap-4">
                            <div className="w-8 h-8 bg-[#00ff88]/10 rounded-full flex items-center justify-center text-[#00ff88] font-black text-xs">{activeChatId.slice(4, 5).toUpperCase()}</div>
                            <div>
                               <p className="text-[10px] font-black uppercase tracking-tight text-white">{activeChatId}</p>
                               <p className="text-[8px] text-[#00ff88] font-bold uppercase">Customer Session</p>
                            </div>
                         </div>
                         <div ref={chatScrollRef} className="flex-1 overflow-y-auto p-8 space-y-4">
                            {chatSessions.find(s => s.userId === activeChatId)?.messages && Object.entries(chatSessions.find(s => s.userId === activeChatId)!.messages!).map(([id, msg]: any) => (
                               <div key={id} className={`flex ${msg.sender === 'admin' ? 'justify-end' : 'justify-start'}`}>
                                  <div className={`max-w-[80%] px-5 py-3 rounded-2xl text-[13px] ${msg.sender === 'admin' ? 'bg-[#00ff88] text-black font-bold' : 'bg-white/5 border border-white/10 text-gray-200'}`}>
                                     {msg.text}
                                  </div>
                               </div>
                            ))}
                         </div>
                         <form onSubmit={handleSendAdminMessage} className="p-6 bg-[#0a0a0a] border-t border-white/5 flex gap-4">
                            <input value={chatInput} onChange={e => setChatInput(e.target.value)} placeholder="Type a response..." className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm outline-none focus:border-[#00ff88]/30" />
                            <button type="submit" className="px-8 bg-[#00ff88] text-black font-black uppercase text-[10px] rounded-xl active:scale-95 transition-all">Send</button>
                         </form>
                      </>
                   ) : (
                      <div className="flex-1 flex flex-col items-center justify-center text-center opacity-20 gap-4">
                         <span className="text-5xl">💬</span>
                         <p className="text-xs font-black uppercase tracking-[0.3em]">Select a chat to begin support</p>
                      </div>
                   )}
                </div>
             </div>
          )}

          {activeTab === 'users' && (
             <div className="space-y-10 animate-in slide-in-from-bottom-5">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                   <div className="bg-[#0a0a0a] p-8 rounded-[2rem] border border-white/5 flex flex-col justify-between h-40 shadow-2xl relative overflow-hidden">
                      <div className="absolute top-0 left-0 w-1 h-full bg-[#00ff88]"></div>
                      <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest">ISSUED CODES</span>
                      <span className="text-5xl font-black text-white">{users.length}</span>
                   </div>
                   <div className="bg-[#0a0a0a] p-8 rounded-[2rem] border border-white/5 flex flex-col justify-between h-40 shadow-2xl relative overflow-hidden">
                      <div className="absolute top-0 left-0 w-1 h-full bg-[#0084ff]"></div>
                      <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest">LIVE USERS</span>
                      <span className="text-5xl font-black text-[#0084ff]">{viewerCount}</span>
                   </div>
                </div>

                <div className="bg-[#0a0a0a] p-10 rounded-[3rem] border border-white/5 max-w-xl mx-auto space-y-6 shadow-2xl relative overflow-hidden">
                   <h3 className="text-sm font-black uppercase text-center tracking-[0.3em] text-[#00ff88]">{editingUserCode ? 'Update Premium Identity' : 'Premium Code Provisioning'}</h3>
                   <div className="space-y-4">
                      <input placeholder="User Name" value={newUser.name || ''} onChange={e => setNewUser({...newUser, name: e.target.value})} className="w-full bg-black/40 border border-white/10 p-5 rounded-2xl text-sm outline-none" />
                      <div className="flex gap-4">
                         <input placeholder="Code" disabled={!!editingUserCode} value={newUser.code || ''} onChange={e => setNewUser({...newUser, code: e.target.value.toUpperCase()})} className="flex-1 bg-black/40 border border-white/10 p-5 rounded-2xl text-sm outline-none font-black tracking-widest" />
                         {!editingUserCode && <button onClick={() => setNewUser({...newUser, code: generate6DigitCode()})} className="px-8 bg-white/5 border border-white/10 rounded-2xl text-[10px] font-black uppercase">ROLL</button>}
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-1">
                          <label className="text-[8px] font-black text-gray-500 uppercase tracking-widest ml-2">DEVICE LIMIT</label>
                          <input type="number" min="1" max="10" value={newUser.deviceLimit || 1} onChange={e => setNewUser({...newUser, deviceLimit: parseInt(e.target.value)})} className="w-full bg-black/40 border border-white/10 p-4 rounded-xl text-sm outline-none font-black" />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[8px] font-black text-gray-500 uppercase tracking-widest ml-2">EXPIRY DAYS</label>
                          <input type="number" min="1" value={expiryDays} onChange={e => setExpiryDays(parseInt(e.target.value))} className="w-full bg-black/40 border border-white/10 p-4 rounded-xl text-sm outline-none font-black" />
                        </div>
                      </div>
                      <button onClick={handleAddUser} className="w-full py-5 bg-[#00ff88] text-black font-black uppercase rounded-2xl text-xs tracking-[0.2em]">
                        {editingUserCode ? 'Update Identity' : 'Deploy Code'}
                      </button>
                      {editingUserCode && <button onClick={() => { setEditingUserCode(null); setNewUser({ name: '', code: '', deviceLimit: 1 }); }} className="w-full text-[9px] font-black text-gray-500 uppercase tracking-widest">Cancel Editing</button>}
                   </div>
                </div>
                
                <div className="bg-[#0a0a0a] rounded-[2.5rem] border border-white/5 overflow-hidden">
                   <table className="w-full text-left text-xs">
                      <thead className="bg-white/5">
                         <tr>
                           <th className="p-6 font-black uppercase tracking-widest text-gray-500">Identity</th>
                           <th className="p-6 font-black uppercase tracking-widest text-gray-500 text-center">Auth Code</th>
                           <th className="p-6 font-black uppercase tracking-widest text-gray-500 text-center">Active/Limit</th>
                           <th className="p-6 font-black uppercase tracking-widest text-gray-500 text-right">Actions</th>
                         </tr>
                      </thead>
                      <tbody className="divide-y divide-white/5">
                         {users.map((u, i) => (
                            <tr key={i} className="hover:bg-white/[0.02]">
                               <td className="p-6 font-bold">{u.name}</td>
                               <td className="p-6 font-mono text-center text-blue-400 font-black text-lg">{u.code}</td>
                               <td className="p-6 font-black text-center text-gray-400">
                                 <span className={Object.keys(u.activeDevices || {}).length >= (u.deviceLimit || 1) ? "text-red-500" : "text-[#00ff88]"}>
                                   {Object.keys(u.activeDevices || {}).length}
                                 </span>
                                 /{u.deviceLimit || 1}
                               </td>
                               <td className="p-6 text-right space-x-4">
                                  <button onClick={() => handleEditUser(u)} className="text-[#00ff88] font-black uppercase text-[10px]">Edit</button>
                                  <button onClick={() => handleResetUserDevices(u.code)} className="text-orange-500 font-black uppercase text-[10px]">Reset</button>
                                  <button onClick={() => handleDeleteUser(u.code)} className="text-red-500 font-black uppercase text-[10px]">Delete</button>
                               </td>
                            </tr>
                         ))}
                      </tbody>
                   </table>
                </div>
             </div>
          )}

          {activeTab === 'ads' && (
             <div className="space-y-10 max-w-4xl mx-auto animate-in slide-in-from-bottom-4">
                <div className="bg-[#0a0a0a] p-8 rounded-[2.5rem] border border-white/5 space-y-8 shadow-2xl">
                   <h3 className="text-sm font-black uppercase tracking-widest text-[#00ff88] border-b border-white/5 pb-4">Banner Management</h3>
                   
                   <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      <div className="space-y-3">
                        <label className="text-[10px] font-black uppercase text-gray-500">Banner Size Width ({settings.ads_banner_width || 50}%)</label>
                        <input type="range" min="10" max="100" value={settings.ads_banner_width || 50} onChange={e => setSettings({...settings, ads_banner_width: parseInt(e.target.value)})} className="w-full accent-[#00ff88]" />
                      </div>
                      <div className="space-y-3">
                        <label className="text-[10px] font-black uppercase text-gray-500">Bottom Offset ({settings.ads_banner_offset_y || 2}%)</label>
                        <input type="range" min="0" max="50" value={settings.ads_banner_offset_y || 2} onChange={e => setSettings({...settings, ads_banner_offset_y: parseInt(e.target.value)})} className="w-full accent-[#00ff88]" />
                      </div>
                   </div>

                   <div className="space-y-4 pt-4 border-t border-white/5">
                      <input value={newAd.image} onChange={e => setNewAd({...newAd, image: e.target.value})} placeholder="Banner Image URL (https://...)" className="w-full bg-black/40 border border-white/10 p-4 rounded-xl text-sm outline-none" />
                      <input value={newAd.link} onChange={e => setNewAd({...newAd, link: e.target.value})} placeholder="Redirect URL (Optional)" className="w-full bg-black/40 border border-white/10 p-4 rounded-xl text-sm outline-none" />
                      <button onClick={handleSaveAd} className="w-full bg-[#00ff88] text-black font-black py-4 rounded-xl uppercase text-[11px] tracking-widest active:scale-95 transition-all">
                        {editingAdIndex !== null ? 'Update Ad' : 'Publish Ad'}
                      </button>
                      {editingAdIndex !== null && <button onClick={() => { setEditingAdIndex(null); setNewAd({ image: '', link: '' }); }} className="w-full text-[9px] font-black text-gray-500 uppercase tracking-widest">Cancel Editing</button>}
                   </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                   {(settings.custom_ads || []).map((ad, idx) => (
                      <div key={idx} className="bg-[#0a0a0a] rounded-[2rem] border border-white/5 overflow-hidden group">
                         <div className="aspect-video bg-black overflow-hidden relative">
                            <img src={ad.image} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                         </div>
                         <div className="p-4 flex gap-3 bg-black/30">
                            <button onClick={() => { setEditingAdIndex(idx); setNewAd(ad); }} className="flex-1 bg-white/5 py-2 rounded-lg text-[9px] font-black uppercase border border-white/10 hover:text-[#00ff88]">Edit</button>
                            <button onClick={async () => { if (confirm('Delete?')) { const updated = (settings.custom_ads || []).filter((_, i) => i !== idx); await set(ref(getDatabase(), 'settings/custom_ads'), updated); } }} className="flex-1 bg-red-600/10 text-red-500 py-2 rounded-lg text-[9px] font-black uppercase border border-red-500/10 hover:bg-red-600 hover:text-white transition-all">Delete</button>
                         </div>
                      </div>
                   ))}
                </div>
             </div>
          )}

          {activeTab === 'settings' && (
             <div className="space-y-6 max-w-4xl mx-auto pb-60 relative">
                <div className="bg-[#0a0a0a] p-8 rounded-[2rem] border border-white/5 space-y-6">
                   <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-[8px] font-black text-gray-500 uppercase ml-2 tracking-widest">OFFSET X (%)</label>
                        <input type="number" value={settings.branding_logo_offset_x || 5} onChange={e => setSettings({...settings, branding_logo_offset_x: parseInt(e.target.value)})} className="w-full bg-black/40 border border-white/10 p-4 rounded-xl text-sm outline-none" />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[8px] font-black text-gray-500 uppercase ml-2 tracking-widest">OFFSET Y (%)</label>
                        <input type="number" value={settings.branding_logo_offset_y || 5} onChange={e => setSettings({...settings, branding_logo_offset_y: parseInt(e.target.value)})} className="w-full bg-black/40 border border-white/10 p-4 rounded-xl text-sm outline-none" />
                      </div>
                   </div>

                   <SettingToggle label="SHOW LOGO ON PLAYER" value={!!settings.show_branding_logo} onChange={v => setSettings({...settings, show_branding_logo: v})} />

                   <div className="space-y-1">
                      <label className="text-[8px] font-black text-gray-500 uppercase ml-2 tracking-widest">SERVER UPDATE BUTTON TEXT</label>
                      <input value={settings.server_update_text || ''} onChange={e => setSettings({...settings, server_update_text: e.target.value})} className="w-full bg-black/40 border border-white/10 p-4 rounded-xl text-sm outline-none" placeholder="ဆာဗာအသစ်ယူရန် နှိပ်ပါ" />
                   </div>

                   <div className="space-y-1">
                      <label className="text-[8px] font-black text-gray-500 uppercase ml-2 tracking-widest">APK DOWNLOAD URL</label>
                      <input value={settings.apk_download_url || ''} onChange={e => setSettings({...settings, apk_download_url: e.target.value})} className="w-full bg-black/40 border border-white/10 p-4 rounded-xl text-sm outline-none" placeholder="https://..." />
                   </div>

                   <div className="space-y-1">
                      <label className="text-[8px] font-black text-gray-500 uppercase ml-2 tracking-widest">APK DOWNLOAD TEXT</label>
                      <input value={settings.apk_download_text || 'APK DOWNLOAD'} onChange={e => setSettings({...settings, apk_download_text: e.target.value})} className="w-full bg-black/40 border border-white/10 p-4 rounded-xl text-sm outline-none" placeholder="APK DOWNLOAD" />
                   </div>

                   <div className="space-y-1">
                      <label className="text-[8px] font-black text-gray-500 uppercase ml-2 tracking-widest">ANNOUNCEMENT TEXT (MARQUEE)</label>
                      <textarea value={settings.announcement_text || ''} onChange={e => setSettings({...settings, announcement_text: e.target.value})} className="w-full bg-black/40 border border-white/10 p-4 rounded-xl text-sm outline-none h-20 resize-none" placeholder="Hello" />
                   </div>

                   <SettingToggle label="ENABLE MARQUEE" value={!!settings.show_announcement} onChange={v => setSettings({...settings, show_announcement: v})} />
                </div>

                <div className="bg-[#0a0a0a] p-8 rounded-[2rem] border border-white/5 space-y-6">
                   <div className="flex items-center gap-3 border-b border-white/5 pb-4">
                      <span className="text-xl">🛠️</span>
                      <h3 className="text-[10px] font-black uppercase tracking-widest text-[#00ff88]">SYSTEM CORE</h3>
                   </div>
                   <div className="space-y-4">
                      <div className="space-y-1">
                        <label className="text-[8px] font-black text-gray-500 uppercase ml-2 tracking-widest">APP LANGUAGE</label>
                        <select value={settings.app_language || 'en'} onChange={e => setSettings({...settings, app_language: e.target.value as any})} className="w-full bg-black/40 border border-white/10 p-4 rounded-xl text-sm outline-none appearance-none">
                           <option value="en">English</option>
                           <option value="my">Myanmar</option>
                        </select>
                      </div>

                      <div className="space-y-1">
                        <label className="text-[8px] font-black text-gray-500 uppercase ml-2 tracking-widest">TOTAL CODE LIMIT (CAPACITY)</label>
                        <input type="number" value={settings.total_code_limit || 10000000} onChange={e => setSettings({...settings, total_code_limit: parseInt(e.target.value)})} className="w-full bg-black/40 border border-white/10 p-4 rounded-xl text-sm outline-none font-bold text-[#00ff88]" />
                      </div>

                      <div className="space-y-1">
                        <label className="text-[8px] font-black text-gray-500 uppercase ml-2 tracking-widest">APP VERSION (CURRENT: {CURRENT_APP_VERSION})</label>
                        <input value={settings.app_version || CURRENT_APP_VERSION} onChange={e => setSettings({...settings, app_version: e.target.value})} className="w-full bg-black/40 border border-white/10 p-4 rounded-xl text-sm outline-none" />
                      </div>

                      <div className="space-y-1">
                        <label className="text-[8px] font-black text-gray-500 uppercase ml-2 tracking-widest">UPDATE DOWNLOAD URL (FORCE)</label>
                        <input value={settings.update_url || ''} onChange={e => setSettings({...settings, update_url: e.target.value})} className="w-full bg-black/40 border border-white/10 p-4 rounded-xl text-sm outline-none" placeholder="https://..." />
                      </div>

                      <div className="flex flex-col gap-1">
                        <SettingToggle label="FORCE UPDATE USER" subLabel="BLOCKS ACCESS IF VERSION MISMATCH" value={!!settings.force_update} onChange={v => setSettings({...settings, force_update: v})} />
                      </div>

                      <div className="space-y-1">
                        <label className="text-[8px] font-black text-gray-500 uppercase ml-2 tracking-widest">ADMIN PASSWORD</label>
                        <input type="password" value={settings.admin_password || ''} onChange={e => setSettings({...settings, admin_password: e.target.value})} className="w-full bg-black/40 border border-white/10 p-4 rounded-xl text-sm outline-none" placeholder="••••••" />
                      </div>

                      <div className="space-y-1">
                        <label className="text-[8px] font-black text-gray-500 uppercase ml-2 tracking-widest">WELCOME TITLE TEXT</label>
                        <input value={settings.welcome_title_text || ''} onChange={e => setSettings({...settings, welcome_title_text: e.target.value})} className="w-full bg-black/40 border border-white/10 p-4 rounded-xl text-sm outline-none" />
                      </div>

                      <div className="space-y-1">
                        <label className="text-[8px] font-black text-gray-500 uppercase ml-2 tracking-widest">SYNC INTERVAL (MINUTES)</label>
                        <input type="number" value={settings.sync_interval || 5} onChange={e => setSettings({...settings, sync_interval: parseInt(e.target.value)})} className="w-full bg-black/40 border border-white/10 p-4 rounded-xl text-sm outline-none" />
                      </div>

                      <div className="flex flex-col gap-1">
                        <SettingToggle label="GUEST MODE (FREE)" subLabel="BYPASS LOGIN SCREEN" value={!!settings.free_mode} onChange={v => setSettings({...settings, free_mode: v})} />
                      </div>

                      <div className="space-y-1">
                        <label className="text-[8px] font-black text-gray-500 uppercase ml-2 tracking-widest">UI DARKNESS LEVEL</label>
                        <select value={settings.app_background_darkness || 'default'} onChange={e => setSettings({...settings, app_background_darkness: e.target.value as any})} className="w-full bg-black/40 border border-white/10 p-4 rounded-xl text-sm outline-none appearance-none">
                           <option value="default">Default</option>
                           <option value="darker">Darker</option>
                           <option value="deep-dark">Deep Dark</option>
                        </select>
                      </div>

                      <div className="pt-6 space-y-4 border-t border-white/5">
                        <h4 className="text-[10px] font-black uppercase text-[#00ff88]">Support & Reply Settings</h4>
                        <div className="space-y-1">
                          <label className="text-[8px] font-black text-gray-500 uppercase ml-2 tracking-widest">PRICING & INSTRUCTIONS (SUPPORT PAGE)</label>
                          <textarea value={settings.pricing_info || ''} onChange={e => setSettings({...settings, pricing_info: e.target.value})} className="w-full bg-black/40 border border-white/10 p-4 rounded-xl text-sm outline-none h-32 resize-none" placeholder="Enter instructions or pricing details for users..." />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[8px] font-black text-gray-500 uppercase ml-2 tracking-widest">AUTO REPLY MESSAGE</label>
                          <input value={settings.auto_reply_text || ''} onChange={e => setSettings({...settings, auto_reply_text: e.target.value})} className="w-full bg-black/40 border border-white/10 p-4 rounded-xl text-sm outline-none" placeholder="Hello! We will get back to you soon." />
                        </div>
                        <SettingToggle label="ENABLE AUTO REPLY" value={!!settings.auto_reply_enabled} onChange={v => setSettings({...settings, auto_reply_enabled: v})} />
                      </div>
                   </div>
                </div>

                <div className="fixed bottom-10 right-10 z-[200]">
                   <button onClick={async () => { await set(ref(getDatabase(), 'settings'), settings); alert('Application Settings Updated!'); }} className="bg-[#00ff88] text-black font-black px-12 py-5 rounded-2xl shadow-2xl active:scale-95 transition-all text-[11px] uppercase tracking-widest ring-4 ring-[#00ff88]/10 flex items-center gap-3">
                     <span className="text-sm">U</span> SAVE CHANGES
                   </button>
                </div>
             </div>
          )}
        </div>

        {/* Match Edit Modal */}
        {editingMatch && (
          <div className="fixed inset-0 z-[300] bg-black/90 backdrop-blur-xl flex items-center justify-center p-6 overflow-y-auto">
            <div className="max-w-4xl w-full bg-[#0a0a0a] border border-white/10 rounded-[3rem] p-10 space-y-8 my-auto animate-in zoom-in duration-300">
               <div className="flex justify-between items-center border-b border-white/5 pb-6">
                 <div>
                   <h3 className="text-xl font-black uppercase italic tracking-tighter text-[#00ff88]">Manual Identity Override</h3>
                   <p className="text-[9px] text-gray-500 font-bold uppercase tracking-widest mt-1">Modifying Match ID: {editingMatch.match_id}</p>
                 </div>
                 <button onClick={() => setEditingMatch(null)} className="w-10 h-10 bg-white/5 rounded-full flex items-center justify-center text-gray-400 hover:text-white transition-all">✕</button>
               </div>

               <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                 <div className="space-y-4">
                   <div className="space-y-1">
                     <label className="text-[8px] font-black text-gray-500 uppercase ml-2">Home Team Name</label>
                     <input value={editingMatch.home_team_name} onChange={e => setEditingMatch({...editingMatch, home_team_name: e.target.value})} className="w-full bg-black border border-white/10 p-4 rounded-xl text-sm outline-none" />
                   </div>
                   <div className="space-y-1">
                     <label className="text-[8px] font-black text-gray-500 uppercase ml-2">Away Team Name</label>
                     <input value={editingMatch.away_team_name} onChange={e => setEditingMatch({...editingMatch, away_team_name: e.target.value})} className="w-full bg-black border border-white/10 p-4 rounded-xl text-sm outline-none" />
                   </div>
                   <div className="grid grid-cols-2 gap-4">
                     <div className="space-y-1">
                        <label className="text-[8px] font-black text-gray-500 uppercase ml-2">Home Score</label>
                        <input value={editingMatch.homeTeamScore || 0} onChange={e => setEditingMatch({...editingMatch, homeTeamScore: e.target.value})} className="w-full bg-black border border-white/10 p-4 rounded-xl text-sm outline-none text-center font-black" />
                     </div>
                     <div className="space-y-1">
                        <label className="text-[8px] font-black text-gray-500 uppercase ml-2">Away Score</label>
                        <input value={editingMatch.awayTeamScore || 0} onChange={e => setEditingMatch({...editingMatch, awayTeamScore: e.target.value})} className="w-full bg-black border border-white/10 p-4 rounded-xl text-sm outline-none text-center font-black" />
                     </div>
                   </div>
                   <div className="space-y-1">
                     <label className="text-[8px] font-black text-gray-500 uppercase ml-2">League Name</label>
                     <input value={editingMatch.league_name || ''} onChange={e => setEditingMatch({...editingMatch, league_name: e.target.value})} className="w-full bg-black border border-white/10 p-4 rounded-xl text-sm outline-none" />
                   </div>
                 </div>

                 <div className="space-y-4">
                   <div className="space-y-1">
                     <label className="text-[8px] font-black text-gray-500 uppercase ml-2">Home Logo URL</label>
                     <input value={editingMatch.home_team_logo} onChange={e => setEditingMatch({...editingMatch, home_team_logo: e.target.value})} className="w-full bg-black border border-white/10 p-4 rounded-xl text-xs outline-none" />
                   </div>
                   <div className="space-y-1">
                     <label className="text-[8px] font-black text-gray-500 uppercase ml-2">Away Logo URL</label>
                     <input value={editingMatch.away_team_logo} onChange={e => setEditingMatch({...editingMatch, away_team_logo: e.target.value})} className="w-full bg-black border border-white/10 p-4 rounded-xl text-xs outline-none" />
                   </div>
                   <div className="space-y-1">
                     <label className="text-[8px] font-black text-gray-500 uppercase ml-2">Match Time (Unix TS)</label>
                     <input value={editingMatch.match_time} onChange={e => setEditingMatch({...editingMatch, match_time: e.target.value})} className="w-full bg-black border border-white/10 p-4 rounded-xl text-sm outline-none font-mono" />
                   </div>
                 </div>
               </div>

               <div className="space-y-4">
                  <h4 className="text-[10px] font-black uppercase text-[#00ff88] tracking-widest border-b border-white/5 pb-2">Stream Channels (Relays)</h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {editingMatch.servers.map((s, sIdx) => (
                      <div key={sIdx} className="bg-black/40 p-4 rounded-2xl border border-white/5 space-y-2">
                        <input value={s.name} onChange={e => {
                          const newServers = [...editingMatch.servers];
                          newServers[sIdx].name = e.target.value;
                          setEditingMatch({...editingMatch, servers: newServers});
                        }} className="w-full bg-transparent border-b border-white/10 p-1 text-[10px] font-black outline-none uppercase" placeholder="Channel Name" />
                        <input value={s.url} onChange={e => {
                          const newServers = [...editingMatch.servers];
                          newServers[sIdx].url = e.target.value;
                          setEditingMatch({...editingMatch, servers: newServers});
                        }} className="w-full bg-transparent p-1 text-[9px] text-gray-500 outline-none truncate" placeholder="M3U8 URL" />
                      </div>
                    ))}
                  </div>
                  <button onClick={() => {
                    setEditingMatch({...editingMatch, servers: [...editingMatch.servers, { name: 'New Channel', url: '' }]});
                  }} className="text-[9px] font-black text-[#00ff88] uppercase tracking-widest">+ Add Channel</button>
               </div>

               <div className="flex gap-4 pt-4">
                 <button onClick={handleSaveEditedMatch} className="flex-1 bg-[#00ff88] text-black font-black py-5 rounded-2xl uppercase tracking-widest text-xs shadow-xl shadow-[#00ff88]/20 transition-all active:scale-95">Commit Override</button>
                 <button onClick={() => setEditingMatch(null)} className="flex-1 bg-white/5 text-gray-400 font-black py-5 rounded-2xl uppercase tracking-widest text-xs border border-white/10">Discard</button>
               </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default AdminPage;
