
export const FIREBASE_CONFIG = {
  apiKey: "AIzaSyAbWsaBv1WddEI5lLrLat3L_olRJ_mHfH0",
  authDomain: "appbuilder-628ad.firebaseapp.com",
  databaseURL: "https://appbuilder-628ad-default-rtdb.firebaseio.com",
  projectId: "appbuilder-628ad",
  storageBucket: "appbuilder-628ad.firebasestorage.app",
  messagingSenderId: "798425025212",
  appId: "1:798425025212:web:1e8c3439a52f3a9d621eb9",
  measurementId: "G-QHSX33J3FD"
};

export const RAPID_API_KEY = "00d1a899cfmsh4d42fdcc7d2d2c6p1d01d5jsn31b68d015b99";
export const RAPID_API_HOST = "football-live-streaming-api.p.rapidapi.com";

export const CURRENT_APP_VERSION = "1.0.0";
